#include <Arduino.h>
// #include "ros.h"
// #include "Wire.h"
#include <ESP32Encoder.h>

// const int freq = 5000;
// const int ledChannel = 0;
// const int resolution = 8; 

// int pulse = 100;
// const int RFDrive = 16;
// const int RBDrive = 13;
// const int LFDrive = 18;
// const int LBDrive = 19;
// const int EncoderLL = 23;
// const int EncoderLR = 25;
// const int EncoderRL = 26;
// const int EncoderRR = 27;
// Encoder NcoderL(EncoderLL, EncoderLR);
// Encoder NcoderR(EncoderRL, EncoderRR);
#define ENCODER_A_PIN 26
#define ENCODER_B_PIN 27


void setup(){
 Serial.begin(115200); // ตั้งค่า Baud rate ที่ต้องการ, ในที่นี้เลือก 115200
  ESP32Encoder::useInternalWeakPullResistors = UP;
  ESP32Encoder::attachHalfDuplexEncoder(ENCODER_A_PIN, ENCODER_B_PIN);
  // Serial.println("Basic Encoder Test:");
  // pinMode(LFDrive, OUTPUT);
  // pinMode(LBDrive, OUTPUT);
  // pinMode(RFDrive, OUTPUT);
  // pinMode(RBDrive, OUTPUT);
  // pinMode(EncoderLL, INPUT);
  // pinMode(EncoderLR, INPUT);
  // pinMode(EncoderRL, INPUT);
  // pinMode(EncoderRR, INPUT);
  // ledcSetup(LFDrive, freq, resolution);
  // ledcSetup(LBDrive, freq, resolution);
  // ledcSetup(RFDrive, freq, resolution);
  // ledcSetup(RBDrive, freq, resolution);
  // ledcAttachPin(LFDrive, ledChannel);
  // ledcAttachPin(LBDrive, ledChannel);
  // ledcAttachPin(RFDrive, ledChannel);
  // ledcAttachPin(RBDrive, ledChannel);
}

void loop() {
  long encoderValue = ESP32Encoder::readEncoder();
  Serial.print("Encoder Value: ");
  Serial.println(encoderValue);
  

  delay(1000); // หรือใส่ระยะเวลาที่ต้องการสำหรับการอ่านค่า Encoder ได้ตามที่คุณต้องการ
}