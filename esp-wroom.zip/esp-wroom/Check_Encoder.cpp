#include "Arduino.h"
#include "Motor.h"
#include "config.h"
#include "Kinematics.h"
#include <ESP32Encoder.h>
#include "PID.h"
#include "ros.h"
#include "geometry_msgs/Twist.h"
#include "std_msgs/Int16MultiArray.h"

ESP32Encoder EncoderFL;
ESP32Encoder EncoderFR;
ESP32Encoder EncoderRL;
ESP32Encoder EncoderRR;

Motor MotorFL(MotorPinFL_A, MotorPinFL_B, MAX_RPM, &EncoderFL, COUNT_PER_REV_FL);
Motor MotorFR(MotorPinFR_A, MotorPinFR_B, MAX_RPM, &EncoderFR, COUNT_PER_REV_FR);
Motor MotorRL(MotorPinRL_A, MotorPinRL_B, MAX_RPM, &EncoderRL, COUNT_PER_REV_RL);
Motor MotorRR(MotorPinRR_A, MotorPinRR_B, MAX_RPM, &EncoderRR, COUNT_PER_REV_RR);

void setup()
{
  Serial.begin(115200);
  EncoderFL.attachSingleEdge(EncoderPinFL_A, EncoderPinFL_B);
  EncoderFR.attachSingleEdge(EncoderPinFR_A, EncoderPinFR_B);
  EncoderRL.attachSingleEdge(EncoderPinRL_A, EncoderPinRL_B);
  EncoderRR.attachSingleEdge(EncoderPinRR_A, EncoderPinRR_B);
  delay(4000);
}

void loop()
{
  // if (EncoderFL.getCount() >= COUNT_PER_REV_FL)
  // {
  //   MotorFL.run(0);
  // }
  // else
  // {
  //   MotorFL.run(10);
  // }
  if (EncoderFR.getCount() >= COUNT_PER_REV_FR)
  {
    MotorFR.run(0);
  }
  else
  {
    MotorFR.run(8);
  }
  // if (EncoderRL.getCount() >= COUNT_PER_REV_RL)
  // {
  //   MotorRL.run(0);
  // }
  // else
  // {
  //   MotorRL.run(8);
  // }
  // if (EncoderRR.getCount() >= COUNT_PER_REV_RR)
  // {
  //   MotorRR.run(0);
  // }
  // else
  // {
  //   MotorRR.run(8);
  // }

  // Serial.println(EncoderFL.getCount());
  // Serial.print(" | ");
  Serial.println(EncoderFR.getCount());
  // Serial.print(" | ");
  // Serial.println(EncoderRL.getCount());
  // Serial.print(" | ");
  // Serial.println(EncoderRR.getCount());
  // Serial.println(" | ");
  // delay(1000);
}
