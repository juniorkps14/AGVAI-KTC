#include "Arduino.h"
#include "Motor.h"
#include "config.h"
#include "Kinematics.h"
#include <ESP32Encoder.h>
#include "PID.h"
#include "ros.h"
#include "geometry_msgs/Twist.h"
#include "std_msgs/Int16MultiArray.h"

ESP32Encoder EncoderL;
ESP32Encoder EncoderR;

Motor MotorL(MotorPinL_A, MotorPinL_B, MAX_RPM, &EncoderL, COUNT_PER_REV_L);
Motor MotorR(MotorPinR_A, MotorPinR_B, MAX_RPM, &EncoderR, COUNT_PER_REV_R);

Kinematics kinematics(Kinematics::DIFFERENTIAL_DRIVE, MAX_RPM, WHEEL_DIAMETER, 0, LR_WHEELS_DISTANCE);

PID MotorL_Pid(PWM_MIN, PWM_MAX, K_P, K_I, K_P);
PID MotorR_Pid(PWM_MIN, PWM_MAX, K_P, K_I, K_P);

// Button buttonA(Button1);
// Button buttonB(Button2);
// Button buttonC(Button3);

#define COMMAND_RATE 30
#define BOTTON_RATE 10 // hz
// #define IMU_PUBLISH_RATE 30 // hz

unsigned long g_prev_command_time = 0;
// unsigned long prev_button_time = 0;
unsigned long prev_control_time = 0;
float g_req_linear_vel_x = 0;
float g_req_linear_vel_y = 0;
float g_req_angular_vel_z = 0;

ros::NodeHandle nh;

// bool imu_is_initialized;
// sensor_msgs::Imu raw_imu_msg;
// void publishIMU();
// ros::Publisher raw_imu_pub("raw_imu", &raw_imu_msg);

geometry_msgs::Twist raw_vel_msg;
// std_msgs::Int16MultiArray raw_sensor_msg;
// std_msgs::Int16MultiArray raw_button_msg;
void commandCallback(const geometry_msgs::Twist &cmd_msg);
ros::Subscriber<geometry_msgs::Twist> cmd_sub("cmd_vel", commandCallback);
ros::Publisher raw_vel_pub("raw_vel", &raw_vel_msg);
// ros::Publisher raw_sensor_pub("raw_sensor", &raw_sensor_msg);
// ros::Publisher raw_button_pub("raw_button", &raw_button_msg);
Kinematics::velocities current_vel;
void moveBase();

void setup()
{
  EncoderL.useInternalWeakPullResistors = UP;
  EncoderR.useInternalWeakPullResistors = UP;
  EncoderL.attachFullQuad(EncoderPinL_A, EncoderPinL_B);
  EncoderR.attachFullQuad(EncoderPinR_A, EncoderPinR_B);
  nh.getHardware()->setBaud(500000);
  nh.initNode();

  nh.subscribe(cmd_sub);
  nh.advertise(raw_vel_pub);
  // nh.advertise(raw_sensor_pub);
  // nh.advertise(raw_button_pub);

  while (!nh.connected())
  {
    nh.spinOnce();
  }
  nh.loginfo("ROBOT CONNECTED");
}

void loop()
{
  unsigned long now = millis();
  // buttonA.loop();
  // buttonB.loop();
  // buttonC.loop();
  if ((now - prev_control_time) >= (1000 / COMMAND_RATE))
  {
    moveBase();
    prev_control_time = now;
  }

  // if ((now - prev_button_time) >= (1000 / BOTTON_RATE))
  //   {
  //     raw_button_msg.data_length = 3;
  //     int button_data[3];
  //     // button_data[0] = buttonA._state;
  //     // button_data[1] = buttonB._state;
  //     // button_data[2] = buttonC._state;

  //     raw_button_msg.data = button_data;
  //     raw_button_pub.publish(&raw_button_msg);

  //     prev_button_time = now;
  if ((now - g_prev_command_time) >= 400)
  {
    MotorL.run(0);
    MotorR.run(0);
  }

  nh.spinOnce();
}
void moveBase()
{
  // MotorL.run(255);
  // MotorR.run(255);
  Kinematics::rpm req_rpm = kinematics.getRPM(g_req_linear_vel_x, g_req_linear_vel_y, g_req_angular_vel_z);

  int current_rpm1 = MotorL.getRPM();
  int current_rpm2 = MotorR.getRPM();

  MotorL.run(MotorL_Pid.compute(req_rpm.motor1, current_rpm1));
  MotorR.run(MotorR_Pid.compute(req_rpm.motor2, current_rpm2));
  current_vel = kinematics.getVelocities(current_rpm1, current_rpm2, 0, 0);

  raw_vel_msg.linear.x = current_vel.linear_x;
  raw_vel_msg.linear.y = current_vel.linear_y;
  raw_vel_msg.angular.z = current_vel.angular_z;

  raw_vel_pub.publish(&raw_vel_msg);
}

void commandCallback(const geometry_msgs::Twist &cmd_msg)
{
  g_req_linear_vel_x = cmd_msg.linear.x;
  g_req_linear_vel_y = cmd_msg.linear.y;
  g_req_angular_vel_z = cmd_msg.angular.z;

  g_prev_command_time = millis();
}