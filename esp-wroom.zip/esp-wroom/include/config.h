#define MotorPinFL_A 18
#define MotorPinFL_B 17

#define MotorPinFR_A 16
#define MotorPinFR_B 4

#define MotorPinRL_A 23
#define MotorPinRL_B 19

#define MotorPinRR_A 32
#define MotorPinRR_B 33

#define EncoderPinFL_A 35
#define EncoderPinFL_B 34

#define EncoderPinFR_A 13
#define EncoderPinFR_B 27

#define EncoderPinRL_A 26
#define EncoderPinRL_B 25

#define EncoderPinRR_A 39
#define EncoderPinRR_B 36

// #define COUNT_PER_REV_FL 6430.0
#define COUNT_PER_REV_FL 6410.0
#define COUNT_PER_REV_FR 6410.0

#define COUNT_PER_REV_RL 6410.0
#define COUNT_PER_REV_RR 6410.0

// นิ่ม
// #define MAX_RPM 500

// นรกแตก
#define MAX_RPM 2000

// #define K_P 1.5  // P constant
// #define K_I 0.25 // I constant
// #define K_D 0.4  // D constant

// ซิ่ง
// #define MAX_RPM 50000
// #define K_P 3.0  // P constant
// #define K_I 0.35 // I constant
// #define K_D 0.15 // D constant

// นิ่ม
#define K_P 0.8   // P constant
#define K_I 1.00  // I constant
#define K_D 0.005 // D constant

#define WHEEL_DIAMETER 0.1522
// #define WHEEL_DIAMETER 0.1524
#define LR_WHEELS_DISTANCE 0.412
#define FR_WHEELS_DISTANCE 0.354
// #define PWM_BITS 8
#define PWM_BITS 8

#define PWM_MAX pow(2, PWM_BITS) - 1
#define PWM_MIN -PWM_MAX