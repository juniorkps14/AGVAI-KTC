// include
#include "Arduino.h"
#include "config.h"
#include "Controller.h"
#include "ros.h"
// #include "Imu.h"
#include "sensor_msgs/Imu.h"
#include "sensor_msgs/MagneticField.h"
#include "geometry_msgs/Twist.h"

#include <std_msgs/Int16MultiArray.h>
// #include "MPU9250.h"
// #include <Adafruit_Sensor.h>
#include <MPU9250_asukiaaa.h>
#include <Adafruit_Sensor.h>
#include "StepMotor.h"
#include "Controller.h"
#include <LiquidCrystal_I2C.h>


LiquidCrystal_I2C lcd(0x27, 16, 2);
sensors_event_t a, g, temp;
MPU9250_asukiaaa mySensor;

#ifdef _ESP32_HAL_I2C_H_
#define SDA_PIN 21
#define SCL_PIN 22
#endif

ros::NodeHandle nh;
unsigned long prev_imu_time = 0;
bool imu_is_initialized;
sensor_msgs::Imu raw_imu_msg;
// ros::Subscriber<std_msgs::Int16MultiArray> sub_cmd("esp_cmd", &messageCb);
// ros::Subscriber<std_msgs::Int16MultiArray> sub_state("ktc_state", &messageSate);
void publishIMU();
ros::Publisher raw_imu_pub("raw_imu", &raw_imu_msg);
// ros::Publisher raw_mag_pub("raw_mag", &raw_mag_msg);

float aX, aY, aZ, aSqrt, gX, gY, gZ, mDirection, mX, mY, mZ;


void setup(){
  Serial.begin(115200);
  while(!Serial);
  #ifdef _ESP32_HAL_I2C_H_ // For ESP32
    Wire.begin(SDA_PIN, SCL_PIN);
    mySensor.setWire(&Wire);
  #endif
  Serial.println("started");
  mySensor.beginAccel();
  mySensor.beginGyro(GYRO_FULL_SCALE_2000_DPS);
  mySensor.beginMag();
  nh.getHardware()->setBaud(500000);
  nh.initNode();
  nh.advertise(raw_imu_pub);
  // nh.subscribe(sub_cmd);
  // nh.subscribe(sub_state);
  nh.loginfo("ESP CONNECTED");
  

}
void loop(){
  // mySensor.accelUpdate();
  // mySensor.gyroUpdate();
  // aX = mySensor.accelX();
  // aY = mySensor.accelY();
  // aZ = mySensor.accelZ();
  // gX = mySensor.gyroX();
  // gY = mySensor.gyroY();
  // gZ = mySensor.gyroZ();
  publishIMU();
  nh.spinOnce();

  // Serial.println(" aX " + String(aX) + " aY " + String(aY) + " aZ " + String(aZ) + "| gX " + String(gX) + " gY " + String(gY) + " gZ " + String(gZ));
  // Serial.println("hello World");
  // delay(1000);
}

void messageCb(const std_msgs::Int16MultiArray &toggle_msg)
{
  if (int(toggle_msg.data[0]) != -1)
  {
    // controller.select(int(toggle_msg.data[0]));
  }
  if (int(toggle_msg.data[1]) != -1)
  {
    if (int(toggle_msg.data[1]))
    {
      // controller.push();
    }
  }
}
void messageSate(const std_msgs::Int16MultiArray &toggle_msg)
{
  lcd.clear();
  if (int(toggle_msg.data[0]) == 0)
  {
    lcd.setCursor(0, 0);
    lcd.print("Setup!");
  }
  if (int(toggle_msg.data[0]) == 1)
  {
    lcd.setCursor(0, 0);
    lcd.print("IDEL!");
  }
  if (int(toggle_msg.data[0]) == 2)
  {
    lcd.setCursor(0, 0);
    lcd.print("RUN!");
  }
  if (int(toggle_msg.data[0]) == 3)
  {
    lcd.setCursor(0, 0);
    lcd.print("RETRY!");
    lcd.setCursor(0, 1);
    String retry = "Point : " + String(toggle_msg.data[1]) + ", P : " + String(toggle_msg.data[2]);
    lcd.print(retry.c_str());
  }
  if (int(toggle_msg.data[0]) == 4)
  {
    lcd.setCursor(0, 0);
    lcd.print("STOP!");
  }
}

void publishIMU()
{
  // mpu.getEvent(&a, &g, &temp);
  // mpu.update();
  // nh.loginfo(String(mpu.getYaw()).c_str());
  // raw_imu.orientation_covariance = {0.0025, 0, 0, 0, 0.0025, 0, 0, 0, 0.0025};
  // raw_imu.angular_velocity_covariance = {0.0025, 0, 0, 0, 0.0025, 0, 0, 0, 0.0025};
  // raw_imu.linear_acceleration_covariance = {0.0025, 0, 0, 0, 0.0025, 0, 0, 0, 0.0025};
  // raw_imu.orientation.x = mpu.getRoll();
  // raw_imu.orientation.y = mpu.getPitch();
  // raw_imu.orientation.z = mpu.getYaw();
  // raw_imu.orientation.w = 1;
  // mpu.accelUpdate();
  mySensor.accelUpdate();
  mySensor.gyroUpdate();
  raw_imu_msg.linear_acceleration.x = mySensor.accelX();
  raw_imu_msg.linear_acceleration.y = mySensor.accelY();
  raw_imu_msg.linear_acceleration.z = mySensor.accelZ();
  raw_imu_msg.angular_velocity.x = mySensor.gyroX();
  raw_imu_msg.angular_velocity.y = mySensor.gyroY();
  raw_imu_msg.angular_velocity.z = mySensor.gyroZ();
  // if (mpu.magUpdate()) 
  // {
  //   raw_mag_msg.magnetic_field.x = mpu.magX();
  //   raw_mag_msg.magnetic_field.y = mpu.magY();
  //   raw_mag_msg.magnetic_field.z = mpu.magZ();

  // nh.loginfo(String(g.gyro.x).c_str());
  // }
  // Serial.print(raw_imu_msg[]);

  raw_imu_pub.publish(&raw_imu_msg);
  // Serial.println(String(raw_imu_msg));
  // Serial.print(" X " + String(raw_imu_msg.linear_acceleration.x) + " ");
  // Serial.print(" Y " + String(raw_imu_msg.linear_acceleration.y) + " ");
  // Serial.print(" Z " + String(raw_imu_msg.linear_acceleration.z) + " ");
  // Serial.println(" X " + String(raw_imu_msg.angular_velocity.x) + " ");
  // Serial.print(" Y " + String(raw_imu_msg.angular_velocity.y) + " ");
  // Serial.print(" Z " + String(raw_imu_msg.angular_velocity.z) + " ");
  // raw_mag_pub.publish(&raw_mag_msg);
}