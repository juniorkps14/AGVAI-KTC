#include "Arduino.h"
#include "Motor.h"
#include "config.h"
#include "Kinematics.h"
#include <ESP32Encoder.h>
#include "PID.h"
#include "ros.h"
#include "geometry_msgs/Twist.h"
#include "std_msgs/Int16MultiArray.h"

ESP32Encoder EncoderFL;
ESP32Encoder EncoderFR;
ESP32Encoder EncoderRL;
ESP32Encoder EncoderRR;

Motor MotorFL(MotorPinFL_A, MotorPinFL_B, MAX_RPM, &EncoderFL, COUNT_PER_REV_FL);
Motor MotorFR(MotorPinFR_A, MotorPinFR_B, MAX_RPM, &EncoderFR, COUNT_PER_REV_FR);
Motor MotorRL(MotorPinRL_A, MotorPinRL_B, MAX_RPM, &EncoderRL, COUNT_PER_REV_RL);
Motor MotorRR(MotorPinRR_A, MotorPinRR_B, MAX_RPM, &EncoderRR, COUNT_PER_REV_RR);

Kinematics kinematics(Kinematics::MECANUM, MAX_RPM, WHEEL_DIAMETER, 0, LR_WHEELS_DISTANCE);

PID MotorFL_Pid(PWM_MIN, PWM_MAX, K_P, K_I, K_D);
PID MotorFR_Pid(PWM_MIN, PWM_MAX, K_P, K_I, K_D);
PID MotorRL_Pid(PWM_MIN, PWM_MAX, K_P, K_I, K_D);
PID MotorRR_Pid(PWM_MIN, PWM_MAX, K_P, K_I, K_D);

#define COMMAND_RATE 50

unsigned long g_prev_command_time = 0;
// unsigned long prev_button_time = 0;
unsigned long prev_control_time = 0;
float g_req_linear_vel_x = 0;
float g_req_linear_vel_y = 0;
float g_req_angular_vel_z = 0;

ros::NodeHandle nh;

// bool imu_is_initialized;
// sensor_msgs::Imu raw_imu_msg;
// void publishIMU();
// ros::Publisher raw_imu_pub("raw_imu", &raw_imu_msg);

geometry_msgs::Twist raw_vel_msg;
// std_msgs::Int16MultiArray raw_sensor_msg;
// std_msgs::Int16MultiArray raw_button_msg;
void commandCallback(const geometry_msgs::Twist &cmd_msg);
ros::Subscriber<geometry_msgs::Twist> cmd_sub("cmd_vel", commandCallback);
ros::Publisher raw_vel_pub("raw_vel", &raw_vel_msg);
// ros::Publisher raw_sensor_pub("raw_sensor", &raw_sensor_msg);
// ros::Publisher raw_button_pub("raw_button", &raw_button_msg);
void moveBase();

void setup()
{
  EncoderFL.attachSingleEdge(EncoderPinFL_A, EncoderPinFL_B);
  EncoderFR.attachSingleEdge(EncoderPinFR_A, EncoderPinFR_B);
  EncoderRL.attachSingleEdge(EncoderPinRL_A, EncoderPinRL_B);
  EncoderRR.attachSingleEdge(EncoderPinRR_A, EncoderPinRR_B);

  // ros init
  nh.getHardware()->setBaud(500000);
  nh.initNode();

  nh.subscribe(cmd_sub);
  nh.advertise(raw_vel_pub);

  while (!nh.connected())
  {
    nh.spinOnce();
  }
  nh.loginfo("ROBOT CONNECTED");
}

void loop()
{

  unsigned long now = millis();
  if ((now - prev_control_time) >= (1000 / COMMAND_RATE))
  {
    moveBase();
    prev_control_time = now;
  }

  if ((now - g_prev_command_time) >= 400)
  {
    MotorFL.run(0);
    MotorFR.run(0);
    MotorRL.run(0);
    MotorRR.run(0);
  }

  nh.spinOnce();

  
}



void moveBase()
{
  Kinematics::rpm req_rpm = kinematics.getRPM(g_req_linear_vel_x, g_req_linear_vel_y, g_req_angular_vel_z);

  int current_rpm1 = MotorFL.getRPM();
  int current_rpm2 = MotorFR.getRPM();
  int current_rpm3 = MotorRL.getRPM();
  int current_rpm4 = MotorRR.getRPM();

  MotorFL.run(MotorFL_Pid.compute(req_rpm.motor1, current_rpm1));
  MotorFR.run(MotorFR_Pid.compute(req_rpm.motor2, current_rpm2));
  MotorRL.run(MotorRL_Pid.compute(req_rpm.motor3, current_rpm3));
  MotorRR.run(MotorRR_Pid.compute(req_rpm.motor4, current_rpm4));

  Kinematics::velocities current_vel;
  current_vel = kinematics.getVelocities(current_rpm1, current_rpm2, current_rpm3, current_rpm4);
  raw_vel_msg.linear.x = current_vel.linear_x;
  raw_vel_msg.linear.y = current_vel.linear_y;
  raw_vel_msg.angular.z = current_vel.angular_z;
  raw_vel_pub.publish(&raw_vel_msg);
}

void commandCallback(const geometry_msgs::Twist &cmd_msg)
{
  g_req_linear_vel_x = cmd_msg.linear.x;
  g_req_linear_vel_y = cmd_msg.linear.y;
  g_req_angular_vel_z = cmd_msg.angular.z;

  g_prev_command_time = millis();
}