#include "Arduino.h"
#include "ros.h"
#include "geometry_msgs/Twist.h"
#include <Wire.h>
#include <Adafruit_BNO08x.h>
#include <std_msgs/Int16MultiArray.h>
#include <Adafruit_Sensor.h>
#define IMU_PUBLISH_RATE 80
#include "sensor_msgs/Imu.h"
#include "sensor_msgs/MagneticField.h"
ros::NodeHandle nh;
unsigned long prev_imu_time = 0;
bool imu_is_initialized = false;

sensor_msgs::Imu raw_imu_msg;
sensor_msgs::MagneticField raw_mag_msg;

#define BNO08X_RESET -1

Adafruit_BNO08x bno08x(BNO08X_RESET);
sh2_SensorValue_t sensorValue;
struct euler_t
{
  float yaw;
  float pitch;
  float roll;
} ypr;

void publishIMU();
ros::Publisher raw_imu_pub("raw_imu", &raw_imu_msg);
// ros::Publisher raw_mag_pub("raw_mag", &raw_mag_msg);

void quaternionToEuler(float qr, float qi, float qj, float qk, euler_t *ypr, bool degrees = false)
{

  float sqr = sq(qr);
  float sqi = sq(qi);
  float sqj = sq(qj);
  float sqk = sq(qk);

  ypr->yaw = atan2(2.0 * (qi * qj + qk * qr), (sqi - sqj - sqk + sqr));
  ypr->pitch = asin(-2.0 * (qi * qk - qj * qr) / (sqi + sqj + sqk + sqr));
  ypr->roll = atan2(2.0 * (qj * qk + qi * qr), (-sqi - sqj + sqk + sqr));

  if (degrees)
  {
    ypr->yaw *= RAD_TO_DEG;
    ypr->pitch *= RAD_TO_DEG;
    ypr->roll *= RAD_TO_DEG;
  }
}

void quaternionToEulerRV(sh2_RotationVectorWAcc_t *rotational_vector, euler_t *ypr, bool degrees = false)
{
  quaternionToEuler(rotational_vector->real, rotational_vector->i, rotational_vector->j, rotational_vector->k, ypr, degrees);
}

void setup()
{

  nh.getHardware()->setBaud(500000);
  nh.initNode();
  nh.advertise(raw_imu_pub);
  // nh.advertise(raw_mag_pub);
  // nh.advertise(controller._state_pub);
  bno08x.begin_I2C();
  Wire.setClock(400000);
  while (!nh.connected())
  {
    nh.spinOnce();
  }
  // nh.loginfo("ESP CONNECTED");
}

void loop()
{
  if ((millis() - prev_imu_time) >= (1000 / IMU_PUBLISH_RATE))
  {
    if (!imu_is_initialized)
    {
      bno08x.enableReport(SH2_ARVR_STABILIZED_RV, 5000);
      nh.loginfo("IMU Initialized");
      imu_is_initialized = true;
    }
    else
    {
      if (bno08x.wasReset())
      {
        nh.loginfo("sensor was reset ");
      }
      if (!bno08x.getSensorEvent(&sensorValue))
      {
        return;
      }
      quaternionToEuler(sensorValue.un.arvrStabilizedRV.real, sensorValue.un.arvrStabilizedRV.i, sensorValue.un.arvrStabilizedRV.j, sensorValue.un.arvrStabilizedRV.k, &ypr, false);
      publishIMU();
    }

    prev_imu_time = millis();
  }

  // controller.loop();
  nh.spinOnce();
}

void publishIMU()
{
  switch (sensorValue.sensorId)
  {
  case SH2_ARVR_STABILIZED_RV:
    raw_imu_msg.header.frame_id = "imu_link";
    raw_imu_msg.orientation.x = ypr.roll;
    raw_imu_msg.orientation.y = ypr.pitch;
    raw_imu_msg.orientation.z = ypr.yaw;
    raw_imu_pub.publish(&raw_imu_msg);
    break;
    // case SH2_MAGNETIC_FIELD_CALIBRATED:
    //   raw_mag_msg.magnetic_field.x = sensorValue.un.magneticField.x;
    //   raw_mag_msg.magnetic_field.y = sensorValue.un.magneticField.y;
    //   raw_mag_msg.magnetic_field.z = sensorValue.un.magneticField.z;
    //   raw_mag_pub.publish(&raw_mag_msg);
    //   break;
  }
}