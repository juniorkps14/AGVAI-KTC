#ifndef ADAPTIVE_PID_H
#define ADAPTIVE_PID_H

#include "PID.h"

class AdaptivePID : public PID
{
public:
    float getKp() const { return kp_; }
    float getKi() const { return ki_; }
    float getKd() const { return kd_; }
    // Constructor
    AdaptivePID(float min_val, float max_val, float kp, float ki, float kd, unsigned long sample_time_ms = 100);

    // Override compute to include adaptive tuning
    double compute(float setpoint, float measured_value) override;

    // Set adaptation rates
    void setAdaptationRates(float kp_rate, float ki_rate, float kd_rate);
    
private:
    float kp_rate_; // Rate of adaptation for Kp
    float ki_rate_; // Rate of adaptation for Ki
    float kd_rate_; // Rate of adaptation for Kd
};

#endif
