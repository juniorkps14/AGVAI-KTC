#include "AdaptivePID.h"

// Constructor
AdaptivePID::AdaptivePID(float min_val, float max_val, float kp, float ki, float kd, unsigned long sample_time_ms)
    : PID(min_val, max_val, kp, ki, kd, sample_time_ms),
      kp_rate_(0.01), // Default adaptation rates
      ki_rate_(0.01),
      kd_rate_(0.01)
{
}

// Set adaptation rates
void AdaptivePID::setAdaptationRates(float kp_rate, float ki_rate, float kd_rate)
{
    kp_rate_ = kp_rate;
    ki_rate_ = ki_rate;
    kd_rate_ = kd_rate;
}

// Override compute to include adaptive tuning
double AdaptivePID::compute(float setpoint, float measured_value)
{
    double output = PID::compute(setpoint, measured_value);

    // Adaptive tuning based on error
    double error = setpoint - measured_value;

    // Simple adaptation logic:
    // If error is decreasing, increase Kp slightly to respond faster
    // If error is increasing, decrease Kp to reduce overshoot
    // Similar logic can be applied for Ki and Kd

    // Placeholder for more sophisticated adaptation logic
    // Here, we use a simple proportional adjustment

    // Example adaptation for Kp
    if (abs(error) < 1.0) // Threshold for small error
    {
        kp_ += kp_rate_;
    }
    else
    {
        kp_ -= kp_rate_;
    }
    kp_ = constrain(kp_, 0.0, 100.0); // Constrain Kp to reasonable range

    // Example adaptation for Ki
    if (abs(error) < 0.5)
    {
        ki_ += ki_rate_;
    }
    else
    {
        ki_ -= ki_rate_;
    }
    ki_ = constrain(ki_, 0.0, 100.0); // Constrain Ki to reasonable range

    // Example adaptation for Kd
    if (abs(error) > 2.0)
    {
        kd_ += kd_rate_;
    }
    else
    {
        kd_ -= kd_rate_;
    }
    kd_ = constrain(kd_, 0.0, 100.0); // Constrain Kd to reasonable range

    // Update tunings in the base PID class
    setTunings(kp_, ki_, kd_);

    return output;
}
