#include "PID.h"

// Constructor
PID::PID(float min_val, float max_val, float kp, float ki, float kd, unsigned long sample_time_ms)
    : min_val_(min_val),
      max_val_(max_val),
      kp_(kp),
      ki_(ki),
      kd_(kd),
      integral_(0.0),
      prev_error_(0.0),
      derivative_(0.0),
      last_time_(0),
      sample_time_(sample_time_ms),
      mode_(AUTOMATIC)
{
}

// Calculate PID output
double PID::compute(float setpoint, float measured_value)
{
    if (mode_ == MANUAL)
    {
        return 0.0;
    }

    unsigned long now = millis();
    unsigned long time_change = now - last_time_;

    if (time_change >= sample_time_)
    {
        double error = setpoint - measured_value;

        // Integrate the error with anti-windup
        integral_ += error * (double(time_change) / 1000.0);
        double max_integral = (max_val_ / ki_) > 1e6 ? 1e6 : (max_val_ / ki_);
        double min_integral = (min_val_ / ki_) < -1e6 ? -1e6 : (min_val_ / ki_);
        integral_ = constrain(integral_, min_integral, max_integral);

        // Calculate derivative
        derivative_ = (error - prev_error_) / (double(time_change) / 1000.0);
        // Additional filtering (e.g., Low-pass filter) can be added here

        // Compute PID output
        double output = (kp_ * error) + (ki_ * integral_) + (kd_ * derivative_);

        // Clamp output to specified limits
        output = constrain(output, min_val_, max_val_);

        // Save error and time for next calculation
        prev_error_ = error;
        last_time_ = now;

        return output;
    }

    return 0.0;
}

// Set PID tunings
void PID::setTunings(float kp, float ki, float kd)
{
    kp_ = kp;
    ki_ = ki;
    kd_ = kd;
}

// Set output limits
void PID::setOutputLimits(float min_val, float max_val)
{
    min_val_ = min_val;
    max_val_ = max_val;

    // Adjust integral term to prevent windup
    integral_ = constrain(integral_, min_val_ / ki_, max_val_ / ki_);
}

// Set sample time in milliseconds
void PID::setSampleTime(unsigned long sample_time_ms)
{
    sample_time_ = sample_time_ms;
}

// Set PID mode (Manual or Automatic)
void PID::setMode(Mode mode)
{
    if (mode != mode_)
    {
        if (mode == AUTOMATIC)
        {
            reset();
        }
        mode_ = mode;
    }
}

// Reset PID calculations
void PID::reset()
{
    integral_ = 0.0;
    prev_error_ = 0.0;
    derivative_ = 0.0;
    last_time_ = millis();
}
