#ifndef PID_H
#define PID_H

#include "Arduino.h"

class PID
{
public:
    // PID operating modes
    enum Mode { MANUAL, AUTOMATIC };

    // Constructor
    PID(float min_val, float max_val, float kp, float ki, float kd, unsigned long sample_time_ms = 100);

    // Calculate PID output
    virtual double compute(float setpoint, float measured_value);

    // Set PID tunings
    void setTunings(float kp, float ki, float kd);

    // Set output limits
    void setOutputLimits(float min_val, float max_val);

    // Set sample time in milliseconds
    void setSampleTime(unsigned long sample_time_ms);

    // Set PID mode (Manual or Automatic)
    void setMode(Mode mode);

    // Reset PID calculations
    void reset();

protected:
    float min_val_;          // Minimum output limit
    float max_val_;          // Maximum output limit
    float kp_;               // Proportional gain
    float ki_;               // Integral gain
    float kd_;               // Derivative gain
    double integral_;        // Integral term
    double prev_error_;      // Previous error
    double derivative_;      // Derivative term
    unsigned long last_time_; // Last computation time
    unsigned long sample_time_; // Sample time in milliseconds
    Mode mode_;              // Current PID mode
};

#endif
