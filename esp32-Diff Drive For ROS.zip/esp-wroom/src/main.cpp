#include "Arduino.h"
#include "Motor.h"
#include "config.h"
#include "Kinematics.h"
#include "ESP32Encoder.h"
#include "AdaptivePID.h" // USE AdaptivePID OR PID
#include "ros.h"
#include "geometry_msgs/Twist.h"
#include "std_msgs/Int16MultiArray.h"

float lowPassFilter(float current_value, float previous_value, float alpha)
{
    return alpha * current_value + (1.0 - alpha) * previous_value;
}


ESP32Encoder EncoderL;
ESP32Encoder EncoderR;

// Initialize motors
Motor MotorL(MotorPinL_A, MotorPinL_B, MAX_RPM, &EncoderL, COUNT_PER_REV_L);
Motor MotorR(MotorPinR_A, MotorPinR_B, MAX_RPM, &EncoderR, COUNT_PER_REV_R);

// Initialize kinematics
Kinematics kinematics(Kinematics::DIFFERENTIAL_DRIVE, MAX_RPM, WHEEL_DIAMETER, 0, LR_WHEELS_DISTANCE);

// Initialize Adaptive PID controllers for left and right motors
AdaptivePID MotorL_Pid(PWM_MIN, PWM_MAX, K_P, K_I, K_D , 33);
AdaptivePID MotorR_Pid(PWM_MIN, PWM_MAX, K_P, K_I, K_D, 33);

#define COMMAND_RATE 30
unsigned long g_prev_command_time = 0;
unsigned long prev_control_time = 0;
float g_req_linear_vel_x = 0;
float g_req_linear_vel_y = 0;
float g_req_angular_vel_z = 0;

// ROS NodeHandle
ros::NodeHandle nh;
geometry_msgs::Twist raw_vel_msg;
void commandCallback(const geometry_msgs::Twist &cmd_msg);
ros::Subscriber<geometry_msgs::Twist> cmd_sub("cmd_vel", commandCallback);
ros::Publisher raw_vel_pub("raw_vel", &raw_vel_msg);
Kinematics::velocities current_vel;

void moveBase()
{
  Kinematics::rpm req_rpm = kinematics.getRPM(g_req_linear_vel_x, g_req_linear_vel_y, g_req_angular_vel_z);
  int current_rpm1 = MotorL.getRPM();
  int current_rpm2 = MotorR.getRPM();
  MotorL.run(MotorL_Pid.compute(req_rpm.motor1, current_rpm1));
  MotorR.run(MotorR_Pid.compute(req_rpm.motor2, current_rpm2));
  current_vel = kinematics.getVelocities(current_rpm1, current_rpm2, 0, 0);
  raw_vel_msg.linear.x = current_vel.linear_x;
  raw_vel_msg.linear.y = current_vel.linear_y;
  raw_vel_msg.angular.z = current_vel.angular_z;
  raw_vel_pub.publish(&raw_vel_msg);
}

void commandCallback(const geometry_msgs::Twist &cmd_msg)
{
  g_req_linear_vel_x = cmd_msg.linear.x;
  g_req_linear_vel_y = cmd_msg.linear.y;
  g_req_angular_vel_z = cmd_msg.angular.z;
  g_prev_command_time = millis();
}

void setup()
{
  // Initialize encoders
  EncoderL.useInternalWeakPullResistors = puType::up;
  EncoderR.useInternalWeakPullResistors = puType::up;
  EncoderL.attachFullQuad(EncoderPinL_A, EncoderPinL_B);
  EncoderR.attachFullQuad(EncoderPinR_A, EncoderPinR_B);
  MotorL_Pid.setMode(PID::AUTOMATIC);
  MotorR_Pid.setMode(PID::AUTOMATIC);
  MotorL_Pid.setAdaptationRates(0.01, 0.01, 0.01);
  MotorR_Pid.setAdaptationRates(0.01, 0.01, 0.01);

  // Initialize ROS
  nh.getHardware()->setBaud(500000);
  nh.initNode();
  nh.subscribe(cmd_sub);
  nh.advertise(raw_vel_pub);
  while (!nh.connected())
  {
    nh.spinOnce();
    delay(100);
  }
  nh.loginfo("ROBOT CONNECTED");
}

void loop()
{
    unsigned long now = micros();
    unsigned long sample_time_us = 1000000 / COMMAND_RATE;

    if ((now - prev_control_time) >= sample_time_us)
    {
        moveBase();
        prev_control_time = now;
    }

    if ((millis() - g_prev_command_time) >= 400)
    {
        MotorL.run(0);
        MotorR.run(0);
    }

    nh.spinOnce();
}

