#define MotorPinL_A 18
#define MotorPinL_B 19

#define MotorPinR_A 16
#define MotorPinR_B 13

#define EncoderPinL_A 26
#define EncoderPinL_B 27

#define EncoderPinR_A 25
#define EncoderPinR_B 23

#define COUNT_PER_REV_L 975.0
#define COUNT_PER_REV_R 975.0

// นิ่ม
#define MAX_RPM 255
#define K_P 0.10 // P constant
#define K_I 0.05 // I constant
#define K_D 0.80 // D constant

#define WHEEL_DIAMETER 0.0835
// #define WHEEL_DIAMETER 0.165
#define LR_WHEELS_DISTANCE 0.295
// #define PWM_BITS 8
#define PWM_BITS 8

#define PWM_MAX pow(2, PWM_BITS) - 1
#define PWM_MIN -PWM_MAX