#ifndef Motor_h
#define Motor_h

#include "Arduino.h"
#include <ESP32Encoder.h>
class Motor
{
private:
    int _pinA;
    int _pinB;
    int _speed = 0;
    int _maxRPM = 0;

    ESP32Encoder *_en;
    int _counts_per_rev;
    unsigned long prev_update_time_;
    long prev_encoder_ticks_;

public:
    int _rpm = 0;
    Motor(int pinA, int pinB, int maxRPM, ESP32Encoder *en, int counts_per_rev);
    void setSpeed(int speed);
    int getSpeed();
    void run(int speed);
    void runRPM(int rpm);
    void run();
    int getRPM();
    ~Motor();
};
#endif