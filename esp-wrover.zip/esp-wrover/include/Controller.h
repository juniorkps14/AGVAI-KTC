
#ifndef _CONTROLLER_H_
#define _CONTROLLER_H_
#include "Arduino.h"
#include "StepMotor.h"
#include "ros.h"
#include <std_msgs/String.h>
enum CONTROLLER_STATE
{
    CONTROLLER_STATE_IDLE,
    CONTROLLER_STATE_CALIBRATE,
    CONTROLLER_STATE_SELECT,
    CONTROLLER_STATE_PUSH,
    CONTROLLER_STATE_STOP
};
enum SUB_CONTROLLER_STATE
{
    SUB_CONTROLLER_STATE_P1,
    SUB_CONTROLLER_STATE_P2,
    SUB_CONTROLLER_STATE_P3,
    SUB_CONTROLLER_STATE_P4,
    SUB_CONTROLLER_STATE_P5
};
/// Floor 1  : 98 +1 +1
/// Floor 2  : 72 -1  -1 -1
/// Floor 3  : 51 -4  -1.5 -2
/// Floor 4  : 33 -6  -2.5 -2
int data_floor[4] = {100, 65, 32, 10};
class Controller
{
private:
    /* data */
    CONTROLLER_STATE _state = CONTROLLER_STATE_IDLE;
    SUB_CONTROLLER_STATE _sub_state = SUB_CONTROLLER_STATE_P1;
    StepMotor *_stepMotorA;
    StepMotor *_stepMotorB;
    int _air_pin;
    int _rate;
    int _floor;
    std_msgs::String _state_msg;
    unsigned long prev_out_time = 0;
    unsigned long prev_time = 0;

public:
    Controller(StepMotor *stepMotorA, StepMotor *stepMotorB, int air, int rate);
    void init();
    void loop();
    void select(int floor);
    void push();
    ros::Publisher _state_pub = ros::Publisher("esp_status", &this->_state_msg);
    ~Controller();
};

Controller::Controller(StepMotor *stepMotorA, StepMotor *stepMotorB, int air, int rate)
{
    this->_stepMotorA = stepMotorA;
    this->_stepMotorB = stepMotorB;
    this->_air_pin = air;
    this->_rate = rate;
}
void Controller::select(int floor)
{
    if (this->_state == CONTROLLER_STATE_IDLE)
    {
        this->_floor = floor;
        this->_state = CONTROLLER_STATE_SELECT;
    }
}
void Controller::push()
{
    if (this->_state == CONTROLLER_STATE_IDLE)
    {
        this->_state = CONTROLLER_STATE_PUSH;
    }
}
void Controller::init()
{
    this->_stepMotorA->init();
    this->_stepMotorB->init();
    pinMode(this->_air_pin, OUTPUT);
    digitalWrite(this->_air_pin, LOW);
    this->_state = CONTROLLER_STATE_CALIBRATE;
}
void Controller::loop()
{
    this->_stepMotorA->loop();
    this->_stepMotorB->loop();
    if (this->_state == CONTROLLER_STATE_IDLE)
    {
    }
    else if (this->_state == CONTROLLER_STATE_CALIBRATE)
    {
        if (this->_sub_state == SUB_CONTROLLER_STATE_P1)
        {
            this->_stepMotorA->calibrate();
            this->_stepMotorB->calibrate();
            this->_sub_state = SUB_CONTROLLER_STATE_P2;
        }
        else if (this->_sub_state == SUB_CONTROLLER_STATE_P2)
        {
            if (this->_stepMotorA->_state == STEP_MOTOR_STATE_IDLE || this->_stepMotorB->_state == STEP_MOTOR_STATE_IDLE)
            {
                this->_sub_state = SUB_CONTROLLER_STATE_P3;
            }
        }
        else if (this->_sub_state == SUB_CONTROLLER_STATE_P3)
        {
            this->_state = CONTROLLER_STATE_STOP;
        }
    }
    else if (this->_state == CONTROLLER_STATE_SELECT)
    {
        if (this->_sub_state == SUB_CONTROLLER_STATE_P1)
        {

            this->_stepMotorA->gotoPercent(data_floor[this->_floor]);
            this->_stepMotorB->gotoPercent(data_floor[this->_floor]);
            this->_sub_state = SUB_CONTROLLER_STATE_P2;
        }
        else if (this->_sub_state == SUB_CONTROLLER_STATE_P2)
        {
            if (this->_stepMotorA->_state == STEP_MOTOR_STATE_IDLE && this->_stepMotorB->_state == STEP_MOTOR_STATE_IDLE)
            {
               this->_state = CONTROLLER_STATE_STOP;
            }
        }
    }
    else if (this->_state == CONTROLLER_STATE_PUSH)
    {
        if (this->_sub_state == SUB_CONTROLLER_STATE_P1)
        {

            this->prev_out_time = millis();
            digitalWrite(this->_air_pin, HIGH);
            // this->_state = CONTROLLER_STATE_STOP;
            // this->_state = CONTROLLER_STATE_PUSH;
            this->_sub_state = SUB_CONTROLLER_STATE_P2;
        }
        else if (this->_sub_state == SUB_CONTROLLER_STATE_P2)
        {
            if ((millis() - this->prev_out_time) >= (1000))
            {
                digitalWrite(this->_air_pin, LOW);
                this->_sub_state = SUB_CONTROLLER_STATE_P3;
            }
        }
        else if (this->_sub_state == SUB_CONTROLLER_STATE_P3)
        {
            this->_state = CONTROLLER_STATE_STOP;
        }
       
    }
    else if (this->_state == CONTROLLER_STATE_STOP)
    {
        this->_state = CONTROLLER_STATE_IDLE;
        this->_sub_state = SUB_CONTROLLER_STATE_P1;
    }

    if ((millis() - this->prev_time) >= (1000 / this->_rate))
    {
        String msg = String(this->_state) + "," + String(this->_sub_state) + "," + String(this->_stepMotorA->_setpoint) + "," + String(this->_stepMotorA->_current_pos) + "," + String(this->_stepMotorA->_max_pos) + "," + String(this->_floor);
        this->_state_msg.data = msg.c_str();
        // Serial.print(this->_stepMotorA->_setpoint);
        // Serial.print(" : ");
        // Serial.print(this->_stepMotorB->_current_pos);
        // Serial.print(" : ");
        // Serial.print(this->_stepMotorB->_max_pos);
        // Serial.print(" : ");
        // Serial.print(this->_floor);
        //  Serial.print(" : ");
        // Serial.println(this->_sub_state);
        this->_state_pub.publish(&this->_state_msg);
        this->prev_time = millis();
    }
}
Controller::~Controller()
{
}
#endif