#define MotorPinFL_A 5
#define MotorPinFL_B 4

#define MotorPinFR_A 3
#define MotorPinFR_B 2

#define MotorPinRL_A 8
#define MotorPinRL_B 9

#define MotorPinRR_A 7
#define MotorPinRR_B 6



#define EncoderPinFL_A 15
#define EncoderPinFL_B 14

#define EncoderPinFR_A 10
#define EncoderPinFR_B 11

#define EncoderPinRL_A 12
#define EncoderPinRL_B 13

#define EncoderPinRR_A A14
#define EncoderPinRR_B A15

#define MotorPinRL_A 8
#define MotorPinRL_B 9

#define StepMotor_A_Pin_Step 25
#define StepMotor_A_Pin_Dir 26

#define Limit_Motor_A 27
#define Limit_Motor_B 13

#define Relay_Motor 19

#define StepMotor_B_Pin_Step 32
#define StepMotor_B_Pin_Dir 33

#define USE_MPU9250_IMU

#define COUNT_PER_REV_FL 1636.0
#define COUNT_PER_REV_FR 1642.0
#define COUNT_PER_REV_RL 1586.0
#define COUNT_PER_REV_RR 1623.0

#define K_P 0.12 // P constant
#define K_I 0.3 // I constant
#define K_D 0.1 // D constant


#define MAX_RPM 280
#define WHEEL_DIAMETER 0.10 
#define LR_WHEELS_DISTANCE 0.475
#define FR_WHEELS_DISTANCE 0.395
#define PWM_BITS 8

#define PWM_MAX pow(2, PWM_BITS) - 1
#define PWM_MIN -PWM_MAX