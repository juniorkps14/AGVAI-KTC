#ifndef _STEPMOTOR_H_
#define _STEPMOTOR_H_
#include "Arduino.h"
enum STEP_MOTOR_STATE
{
    STEP_MOTOR_STATE_IDLE,
    STEP_MOTOR_STATE_CALIBRATE,
    STEP_MOTOR_STATE_GOTO,
    STEP_MOTOR_STATE_STOP
};
enum SUB_STEP_MOTOR_STATE
{
    SUB_STEP_MOTOR_STATE_P1,
    SUB_STEP_MOTOR_STATE_P2,
    SUB_STEP_MOTOR_STATE_P3,
    SUB_STEP_MOTOR_STATE_P4,
    SUB_STEP_MOTOR_STATE_P5
};
class StepMotor
{
private:
    /* data */

    int _step_pin;
    int _dir_pin;

    bool _reverse = false;
    TaskHandle_t _task;

public:
    STEP_MOTOR_STATE _state = STEP_MOTOR_STATE_IDLE;
    SUB_STEP_MOTOR_STATE _sub_state = SUB_STEP_MOTOR_STATE_P1;
    int _current_pos = 0;
    int _max_pos = 0;
    int _setpoint = 0;
    int _limit_pinA;
    int _limit_pinB;
    StepMotor(int step_pin, int dir_pin, int limit_pinA, int limit_pinB);
    void init();
    void gotoPosition(int setpoint);
    void gotoPercent(int percent);
    void calibrate();
    void setDirection(bool dir);
    void setReverse(bool reverse);
    void loop();
    static void run(void *parameter);
    ~StepMotor();
};

StepMotor::StepMotor(int step_pin, int dir_pin, int limit_pinA, int limit_pinB)
{

    this->_step_pin = step_pin;
    this->_dir_pin = dir_pin;
    this->_limit_pinA = limit_pinA;
    this->_limit_pinB = limit_pinB;
}
void StepMotor::init()
{
    pinMode(this->_step_pin, OUTPUT);
    pinMode(this->_dir_pin, OUTPUT);
    pinMode(this->_limit_pinA, INPUT);
    pinMode(this->_limit_pinB, INPUT);
    xTaskCreatePinnedToCore(
        this->run,    /* Function to implement the task */
        "Task",       /* Name of the task */
        5000,         /* Stack size in words */
        this,         /* Task input parameter */
        0,            /* Priority of the task */
        &this->_task, /* Task handle. */
        0);           /* Core where the task should run */
}

void StepMotor::gotoPosition(int setpoint)
{
    this->_setpoint = setpoint;
    this->_state = STEP_MOTOR_STATE_GOTO;
}
void StepMotor::gotoPercent(int percent)
{
    int positionPercent = map(percent, 0, 100, 0, this->_max_pos);
    this->_setpoint = positionPercent;
    this->_state = STEP_MOTOR_STATE_GOTO;
}
void StepMotor::run(void *parameter)
{
    StepMotor *_stepMotor = (StepMotor *)parameter;
    bool _dir = false;
    for (;;)
    {
        _dir = digitalRead(_stepMotor->_dir_pin);
        // Serial.println("run");

        if (_stepMotor->_state != STEP_MOTOR_STATE_IDLE && _stepMotor->_state != STEP_MOTOR_STATE_STOP && _stepMotor->_sub_state != SUB_STEP_MOTOR_STATE_P1)
        {

            digitalWrite(_stepMotor->_step_pin, HIGH);
            delayMicroseconds(62);
            digitalWrite(_stepMotor->_step_pin, LOW);
            delayMicroseconds(62);
            if (!_dir)
            {
                _stepMotor->_current_pos += 1;
            }
            else
            {
                _stepMotor->_current_pos -= 1;
            }
        }
    }
}
void StepMotor::setDirection(bool dir)
{
    digitalWrite(this->_dir_pin, this->_reverse ? !dir : dir);
}
void StepMotor::setReverse(bool reverse)
{
    this->_reverse = reverse;
}

void StepMotor::calibrate()
{
    this->_state = STEP_MOTOR_STATE_CALIBRATE;
}
void StepMotor::loop()
{
    bool _limitA = digitalRead(this->_limit_pinA);
    bool _limitB = digitalRead(this->_limit_pinB);
    if (this->_state == STEP_MOTOR_STATE_IDLE)
    {
    }
    else if (this->_state == STEP_MOTOR_STATE_CALIBRATE)
    {
        if (this->_sub_state == SUB_STEP_MOTOR_STATE_P1)
        {
            this->setDirection(false);
            this->_sub_state = SUB_STEP_MOTOR_STATE_P2;
        }
        else if (this->_sub_state == SUB_STEP_MOTOR_STATE_P2)
        {
            if (!_limitB)
            {
                this->setDirection(true);
                this->_current_pos = 0;
                this->_max_pos = 0;
                this->_sub_state = SUB_STEP_MOTOR_STATE_P3;
            }
        }
        else if (this->_sub_state == SUB_STEP_MOTOR_STATE_P3)
        {
            if (!_limitA)
            {
                this->setDirection(false);
                this->_max_pos = this->_current_pos;
                this->_current_pos = 0;
                this->_sub_state = SUB_STEP_MOTOR_STATE_P4;
            }
        }
        else if (this->_sub_state == SUB_STEP_MOTOR_STATE_P4)
        {
            if (!_limitB)
            {
                this->_current_pos = 0;
                this->_state = STEP_MOTOR_STATE_STOP;
            }
        }
    }
    else if (this->_state == STEP_MOTOR_STATE_GOTO)
    {
        if (this->_sub_state == SUB_STEP_MOTOR_STATE_P1)
        {
            if (this->_current_pos - this->_setpoint < 0)
            {
                this->setDirection(true);
                this->_sub_state = SUB_STEP_MOTOR_STATE_P2;
            }
            else if (this->_current_pos - this->_setpoint > 0)
            {
                this->setDirection(false);
                this->_sub_state = SUB_STEP_MOTOR_STATE_P2;
            }
            else
            {
                this->_state = STEP_MOTOR_STATE_IDLE;
            }
        }
        else if (this->_sub_state == SUB_STEP_MOTOR_STATE_P2)
        {
            if (digitalRead(this->_dir_pin)==LOW)
            {
                if (this->_current_pos >= this->_setpoint)
                {
                    this->_state = STEP_MOTOR_STATE_STOP;
                }
            }
            else
            {
                if (this->_current_pos <= this->_setpoint)
                {
                    this->_state = STEP_MOTOR_STATE_STOP;
                }
            }
        }
    }
    else if (this->_state == STEP_MOTOR_STATE_STOP)
    {
        this->_state = STEP_MOTOR_STATE_IDLE;
        this->_sub_state = SUB_STEP_MOTOR_STATE_P1;
    }
}
StepMotor::~StepMotor()
{
}
#endif