#include "Arduino.h"
#include "ros.h"
#include "AccelStepper.h"
#include <std_msgs/Int16.h>
#include <std_msgs/Int16MultiArray.h>
#include <LiquidCrystal_I2C.h>

TaskHandle_t Task1;
TaskHandle_t Task2;
LiquidCrystal_I2C lcd(0x27, 20, 4);

const int xSTP = 33;
const int xDIR = 32;

const int sol_A = 26;
const int sol_B = 27;
const int sol_C = 25;

const int btn1 = 17;
const int btn2 = 19;
const int btn3 = 18;
const int btn4 = 5;

// int StepsPerRevolution = 200;
// AccelStepper stepper(1, xSTP, xDIR);
AccelStepper stepper(1, xSTP, xDIR);

// Stepper myStepper(stepsPerRevolution, 8, 9, 10, 11);
int position;
int Angle = 1450;

int positionA = Angle * 0;
int positionB = Angle * 1;
int positionC = Angle * 2;
int positionD = Angle * 3;

// init
ros::NodeHandle nh;
// std_msgs::Int32 status_state;

// ros::Publisher esp_state("esp_status", &status_state);

std_msgs::Int16 btn_int;
std_msgs::Int16 callback;
ros::Publisher raw_button("raw_button", &btn_int);
ros::Publisher callback_state("callback_state", &callback);

void statesA_Sol()
{
  digitalWrite(sol_A, LOW);
  delay(200);
  digitalWrite(sol_B, LOW);
  delay(300);
  digitalWrite(sol_C, LOW);
  delay(200);
  digitalWrite(sol_B, HIGH);
  delay(300);
  digitalWrite(sol_A, HIGH);
  delay(300);
  digitalWrite(sol_C, LOW);
  delay(300);
  digitalWrite(sol_B, LOW);
  delay(200);
  digitalWrite(sol_C, HIGH);
  delay(200);
  digitalWrite(sol_B, HIGH);
}

void statesB_Sol()
{
  digitalWrite(sol_B, LOW);
  delay(300);
  digitalWrite(sol_C, LOW);
  delay(200);
  digitalWrite(sol_B, HIGH);
  delay(500);
  digitalWrite(sol_A, LOW);
  delay(300);
  digitalWrite(sol_B, LOW);
  delay(300);
  digitalWrite(sol_C, HIGH);
  delay(300);
  digitalWrite(sol_B, HIGH);
  delay(200);
  digitalWrite(sol_A, HIGH);
  delay(200);
}

void stepState(const std_msgs::Int16MultiArray &toggle_msg)
{
  if (int(toggle_msg.data[0]) == 0)
  {
    callback.data = 0;
    callback_state.publish(&callback);
    stepper.runToNewPosition(positionA);
  }
  if (int(toggle_msg.data[0]) == 1)
  {
    callback.data = 0;
    callback_state.publish(&callback);
    stepper.runToNewPosition(positionB);
  }
  if (int(toggle_msg.data[0]) == 2)
  {
    callback.data = 0;
    callback_state.publish(&callback);
    stepper.runToNewPosition(positionC);
  }
  if (int(toggle_msg.data[0]) == 3)
  {
    callback.data = 0;
    callback_state.publish(&callback);
    stepper.runToNewPosition(positionD);
  }
  if (int(toggle_msg.data[1]) == 1)
  {
    callback.data = 0;
    callback_state.publish(&callback);
    statesA_Sol();
  }
  if (int(toggle_msg.data[1]) == 2)
  {
    callback.data = 0;
    callback_state.publish(&callback);
    statesB_Sol();
  }
  else
  {
    callback.data = 1;
    callback_state.publish(&callback);
  }
}

void messageSate(const std_msgs::Int16MultiArray &toggle_msg)

{
  lcd.clear();
  if (int(toggle_msg.data[0]) == 0)
  {
    lcd.setCursor(0, 0);
    lcd.print("Setup!");
  }
  if (int(toggle_msg.data[0]) == 1)
  {
    lcd.setCursor(0, 0);
    lcd.print("IDEL!");
  }
  if (int(toggle_msg.data[0]) == 2)
  {
    lcd.setCursor(0, 0);
    lcd.print("RUN!");
  }
  if (int(toggle_msg.data[0]) == 3)
  {
    lcd.setCursor(0, 0);
    lcd.print("RETRY!");
    lcd.setCursor(0, 1);
    String retry = "Point : " + String(toggle_msg.data[1]) + ", P : " + String(toggle_msg.data[2]);
    lcd.print(retry.c_str());
  }
  if (int(toggle_msg.data[0]) == 4)
  {
    lcd.setCursor(0, 0);
    lcd.print("STOP!");
  }
}

void btn_state()
{
  if (digitalRead(btn1) == LOW)
  {
    btn_int.data = 1;
    raw_button.publish(&btn_int);
  }
  if (digitalRead(btn2) == LOW)
  {
    btn_int.data = 2;
    raw_button.publish(&btn_int);
  }
  if (digitalRead(btn3) == LOW)
  {
    btn_int.data = 3;
    raw_button.publish(&btn_int);
  }
  if (digitalRead(btn4) == LOW)
  {
    btn_int.data = 4;
    raw_button.publish(&btn_int);
  }
}

ros::Subscriber<std_msgs::Int16MultiArray> sub_cmd("esp_cmd", &stepState);
ros::Subscriber<std_msgs::Int16MultiArray> sub_state("ktc_state", &messageSate);

void Task1code(void *pvParameters)
{
  for (;;)
  {
    // btn_int.data = 1;
    // raw_button.publish(&btn_int);
    vTaskDelay(200);
    nh.spinOnce();
  }
}

void Task2code(void *pvParameters)
{
  for (;;)
  {
    btn_state();
    vTaskDelay(200);
  }
}

void setup()
{
  lcd.init();
  lcd.backlight();
  nh.getHardware()->setBaud(38400);
  nh.initNode();

  pinMode(xSTP, OUTPUT);
  pinMode(xDIR, OUTPUT);
  pinMode(sol_A, OUTPUT);
  pinMode(sol_B, OUTPUT);
  pinMode(sol_C, OUTPUT);
  pinMode(btn1, INPUT);
  pinMode(btn2, INPUT);
  pinMode(btn3, INPUT);
  pinMode(btn4, INPUT);
  stepper.setMaxSpeed(3500);
  stepper.setAcceleration(8000);
  // stepper.setSpeed(500);
  digitalWrite(sol_A, HIGH);
  digitalWrite(sol_B, HIGH);
  digitalWrite(sol_C, HIGH);

  // nh.advertise(esp_state);
  nh.advertise(raw_button);
  nh.advertise(callback_state);
  nh.subscribe(sub_cmd);
  nh.subscribe(sub_state);

  while (!nh.connected())
  {
    nh.spinOnce();
  }
  nh.loginfo("TRAY CONNECTED");

  /*dual core */
  xTaskCreatePinnedToCore(
      Task1code, /* Task function. */
      "Task1",   /* name of task. */
      10000,     /* Stack size of task */
      NULL,      /* parameter of the task */
      1,         /* priority of the task */
      &Task1,    /* Task handle to keep track of created task */
      0);        /* pin task to core 0 */
  delay(500);
 
  xTaskCreatePinnedToCore(
      Task2code, /* Task function. */
      "Task2",   /* name of task. */
      10000,     /* Stack size of task */
      NULL,      /* parameter of the task */
      1,         /* priority of the task */
      &Task2,    /* Task handle to keep track of created task */
      1);        /* pin task to core 1 */
  delay(500);
}

void loop()
{
  // stepper.runSpeed();
  // nh.spinOnce();
}
