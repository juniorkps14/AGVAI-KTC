#include "Arduino.h"
#include "ros.h"
#include "AccelStepper.h"
#include <std_msgs/Int16.h>
#include <std_msgs/String.h>
#include <std_msgs/Int16MultiArray.h>
#include <LiquidCrystal_I2C.h>
unsigned long prev_control_time = 0;
unsigned long prev_arm_time = 0;
TaskHandle_t Task1;
TaskHandle_t Task2;
LiquidCrystal_I2C lcd(0x27, 20, 4);

const int xSTP = 33;
const int xDIR = 32;

const int sol_A = 26;
const int sol_B = 27;
const int sol_C = 25;

const int btn1 = 17;
const int btn2 = 19;
const int btn3 = 18;
const int btn4 = 5;

// int StepsPerRevolution = 200;
// AccelStepper stepper(1, xSTP, xDIR);
AccelStepper stepper(1, xSTP, xDIR);

// Stepper myStepper(stepsPerRevolution, 8, 9, 10, 11);
int position;
int Angle = 1450;

int positionA = Angle * 0;
int positionB = Angle * 1;
int positionC = Angle * 2;
int positionD = Angle * 3;

int Tray = 0;
int cb = -1;
// init
ros::NodeHandle nh;
// std_msgs::Int32 status_state;

// ros::Publisher esp_state("esp_status", &status_state);

std_msgs::Int16 btn_int;
std_msgs::Int16 callback;
std_msgs::Int16 tray_now;
ros::Publisher raw_button("raw_button", &btn_int);
ros::Publisher callback_state("callback_state", &callback);

void statesA_Sol()
{
  digitalWrite(sol_C, HIGH);
  digitalWrite(sol_A, LOW);
  delay(200);
  digitalWrite(sol_B, LOW);
  delay(200);
  digitalWrite(sol_C, LOW);
  delay(100);
  digitalWrite(sol_B, HIGH);
  digitalWrite(sol_A, HIGH);
  delay(300);
  digitalWrite(sol_B, LOW);
  delay(100);
  digitalWrite(sol_C, HIGH);
  delay(200);
  digitalWrite(sol_B, HIGH);
}

void statesB_Sol()
{
  digitalWrite(sol_B, LOW);
  delay(100);
  digitalWrite(sol_C, LOW);
  delay(200);
  digitalWrite(sol_B, HIGH);
}

void statesC_Sol()
{
  digitalWrite(sol_A, LOW);
  delay(200);
  digitalWrite(sol_C, LOW);
  delay(200);
  digitalWrite(sol_B, LOW);
  digitalWrite(sol_C, HIGH);
  delay(200);
  digitalWrite(sol_A, HIGH);
  digitalWrite(sol_B, HIGH);
}

void vip_setup()
{
  stepper.runToNewPosition(positionD);
  digitalWrite(sol_B, LOW);
  delay(100);
  digitalWrite(sol_C, LOW);
  delay(200);
  digitalWrite(sol_B, HIGH);
}

void statesSetup_Sol()
{
  digitalWrite(sol_B, HIGH);
  digitalWrite(sol_C, HIGH);
  digitalWrite(sol_B, HIGH);
}

void stepState(const std_msgs::Int16MultiArray &toggle_msg)
{
  if (int(toggle_msg.data[0]) == 0)
  {
    stepper.runToNewPosition(positionA);
  }
  else if (int(toggle_msg.data[0]) == 1)
  {
    stepper.runToNewPosition(positionB);
  }
  else if (int(toggle_msg.data[0]) == 2)
  {
    stepper.runToNewPosition(positionC);
  }

  else if (int(toggle_msg.data[0]) == 3)
  {
    stepper.runToNewPosition(positionD);
  }

  else if (int(toggle_msg.data[0]) == 4)
  {
    statesA_Sol();
  }
  else if (int(toggle_msg.data[0]) == 5)
  {
    statesB_Sol();
  }
  else if (int(toggle_msg.data[0]) == 6)
  {
    statesB_Sol();
    delay(100);
    statesC_Sol();
  }

  else if (int(toggle_msg.data[0]) == 10)
  {
    statesSetup_Sol();
  }
  else if (int(toggle_msg.data[0]) == 24)
  {
    stepper.runToNewPosition(positionD);
    statesB_Sol();
  }
  else if (int(toggle_msg.data[0]) == 25)
  {
    statesC_Sol();
  }
}

void messageSate(const std_msgs::Int16MultiArray &toggle_msg)

{
  lcd.clear();
  if (int(toggle_msg.data[0]) == 0)
  {
    lcd.setCursor(0, 0);
    lcd.print("Setup!");
  }
  if (int(toggle_msg.data[0]) == 1)
  {
    lcd.setCursor(0, 0);
    lcd.print("IDEL!");
  }
  if (int(toggle_msg.data[0]) == 2)
  {
    lcd.setCursor(0, 0);
    lcd.print("RUN!");
  }
  if (int(toggle_msg.data[0]) == 3)
  {
    lcd.setCursor(0, 0);
    lcd.print("RETRY!");
  }
  if (int(toggle_msg.data[0]) == 4)
  {
    lcd.setCursor(0, 0);
    lcd.print("STOP!");
  }
}

void btn_state()
{
  if (digitalRead(btn1) == LOW)
  {
    delay(200);
    btn_int.data = 1;
    raw_button.publish(&btn_int);
  }
  if (digitalRead(btn2) == LOW)
  {
    delay(200);
    btn_int.data = 2;
    raw_button.publish(&btn_int);
  }
  if (digitalRead(btn3) == LOW)
  {
    delay(200);
    btn_int.data = 3;
    raw_button.publish(&btn_int);
  }
  if (digitalRead(btn4) == LOW)
  {
    delay(200);
    btn_int.data = 4;
    raw_button.publish(&btn_int);
  }
}

// ros::Subscriber<std_msgs::String> sub_qr_string("qr_string", &qr_string_msg);
ros::Subscriber<std_msgs::Int16MultiArray> sub_cmd("esp_cmd", &stepState);
ros::Subscriber<std_msgs::Int16MultiArray> sub_state("ktc_state", &messageSate);

// void Task1code(void *pvParameters)
// {
//   for (;;)
//   {
//     unsigned long now = millis();
//     if ((now - prev_control_time) >= (1000 / 30))
//     {
//       nh.spinOnce();
//       btn_state();
//       prev_control_time = now;
//     }
//   }
// }

// void Task2code(void *pvParameters)
// {
//   for (;;)
//   {
//     unsigned long now = millis();
//     if ((now - prev_arm_time) >= (1000 / 5))
//     {
//       btn_state();
//       prev_arm_time = now;
//     }
//   }
// }

void setup()
{
  lcd.init();
  lcd.backlight();
  nh.getHardware()->setBaud(500000);
  nh.initNode();

  pinMode(xSTP, OUTPUT);
  pinMode(xDIR, OUTPUT);
  pinMode(sol_A, OUTPUT);
  pinMode(sol_B, OUTPUT);
  pinMode(sol_C, OUTPUT);
  pinMode(btn1, INPUT);
  pinMode(btn2, INPUT);
  pinMode(btn3, INPUT);
  pinMode(btn4, INPUT);
  stepper.setMaxSpeed(26000);
  stepper.setAcceleration(18000);
  // stepper.setSpeed(500);
  digitalWrite(sol_A, HIGH);
  digitalWrite(sol_B, HIGH);
  digitalWrite(sol_C, HIGH);

  // nh.advertise(esp_state);
  // nh.advertise(tray_now_state);
  nh.advertise(raw_button);
  nh.advertise(callback_state);
  // nh.subscribe(sub_qr_string);
  nh.subscribe(sub_cmd);
  nh.subscribe(sub_state);

  while (!nh.connected())
  {
    nh.spinOnce();
  }
  nh.loginfo("TRAY CONNECTED");

  // /*dual core */
  // xTaskCreatePinnedToCore(
  //     Task1code, /* Task function. */
  //     "Task1",   /* name of task. */
  //     20000,     /* Stack size of task */
  //     NULL,      /* parameter of the task */
  //     1,         /* priority of the task */
  //     &Task1,    /* Task handle to keep track of created task */
  //     0);        /* pin task to core 0 */
  // delay(500);

  // xTaskCreatePinnedToCore(
  //     Task2code, /* Task function. */
  //     "Task2",   /* name of task. */
  //     20000,     /* Stack size of task */
  //     NULL,      /* parameter of the task */
  //     1,         /* priority of the task */
  //     &Task2,    /* Task handle to keep track of created task */
  //     1);        /* pin task to core 1 */
  // delay(500);
}

void loop()
{
  unsigned long now = millis();
  if ((now - prev_control_time) >= (1000 / 30))
  {
    nh.spinOnce();
    btn_state();
    prev_control_time = now;
  }
}
