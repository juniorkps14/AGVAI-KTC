#include "Arduino.h"
#include "ros.h"
#include "AccelStepper.h"
// #include <Stepper.h>
#include "sensor_msgs/Imu.h"
#include "sensor_msgs/MagneticField.h"
#include "geometry_msgs/Twist.h"
#include <std_msgs/Int16MultiArray.h>
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 20, 4);

const int xSTP = 33;
const int xDIR = 32;

const int sol_A = 26;
const int sol_B = 27;
const int sol_C = 25;

int StepsPerRevolution = 400;
// AccelStepper stepper(1, xSTP, xDIR);
AccelStepper stepper(1, xSTP, xDIR);

// Stepper myStepper(stepsPerRevolution, 8, 9, 10, 11);
int position;
int Angle = 1450;

int positionA = Angle * 0;
int positionB = Angle * 1;
int positionC = Angle * 2;
int positionD = Angle * 3;

// ros init
ros::NodeHandle nh;

void statesA_Sol()
{
     digitalWrite(sol_A, LOW);
     delay(200);
     digitalWrite(sol_B, LOW);
     delay(300);
     digitalWrite(sol_C, LOW);
     delay(200);
     digitalWrite(sol_B, HIGH);
     delay(300);
     digitalWrite(sol_A, HIGH);
     delay(300);
     digitalWrite(sol_C, LOW);
     delay(300);
     digitalWrite(sol_B, LOW);
     delay(200);
     digitalWrite(sol_C, HIGH);
     delay(200);
     digitalWrite(sol_B, HIGH);
}

void statesB_Sol()
{
     digitalWrite(sol_B, LOW);
     delay(300);
     digitalWrite(sol_C, LOW);
     delay(200);
     digitalWrite(sol_B, HIGH);
     delay(500);
     digitalWrite(sol_A, LOW);
     delay(300);
     digitalWrite(sol_B, LOW);
     delay(300);
     digitalWrite(sol_C, HIGH);
     delay(300);
     digitalWrite(sol_B, HIGH);
     delay(200);
     digitalWrite(sol_A, HIGH);
     delay(200);
}

// void messageCb(const std_msgs::Int16MultiArray &toggle_msg)
// {
//   if (int(toggle_msg.data[0]) != -1)
//   {
//     // controller.select(int(toggle_msg.data[0]));
//   }
//   if (int(toggle_msg.data[1]) != -1)
//   {
//     if (int(toggle_msg.data[1]))
//     {
//       // controller.push();
//     }
//   }
// }

void messageSate(const std_msgs::Int16MultiArray &toggle_msg)
{
     if (int(toggle_msg.data[0]) == 0)
     {
          stepper.runToNewPosition(positionA);
     }
     if (int(toggle_msg.data[0]) == 1)
     {
          stepper.runToNewPosition(positionB);
     }
     if (int(toggle_msg.data[0]) == 2)
     {
          stepper.runToNewPosition(positionC);
     }
     if (int(toggle_msg.data[0]) == 3)
     {
          stepper.runToNewPosition(positionD);
     }
     if (int(toggle_msg.data[0]) == 4)
     {
          statesA_Sol();
     }
     if (int(toggle_msg.data[0]) == 5)
     {
          statesB_Sol();
     }
     if (int(toggle_msg.data[0]) == 6)
     {
     }
}

ros::Subscriber<std_msgs::Int16MultiArray> sub_cmd("esp_cmd", &messageSate);
// ros::Publisher pub_state("esp_status", &messageCb);

void setup()
{
     nh.getHardware()->setBaud(500000);
     nh.initNode();

     pinMode(xSTP, OUTPUT);
     pinMode(xDIR, OUTPUT);
     pinMode(sol_A, OUTPUT);
     pinMode(sol_B, OUTPUT);
     pinMode(sol_C, OUTPUT);
     stepper.setMaxSpeed(2400);
     stepper.setAcceleration(10000);
     stepper.setSpeed(600);
     digitalWrite(sol_A, HIGH);
     digitalWrite(sol_B, HIGH);
     digitalWrite(sol_C, HIGH);

     // nh.advertise(pub_state);
     nh.subscribe(sub_cmd);

     while (!nh.connected())
     {
          nh.spinOnce();
     }
     nh.loginfo("TRAY CONNECTED");
     lcd.init(); // initialize the lcd
     // Print a message to the LCD.
     lcd.backlight();
     lcd.setCursor(3, 0);
     lcd.print("Hello, world!");
     lcd.setCursor(2, 1);
     lcd.print("Ywrobot Arduino!");
     lcd.setCursor(0, 2);
     lcd.print("Arduino LCM IIC 2004");
     lcd.setCursor(2, 3);
     lcd.print("Power By Ec-yuan!");
}

void loop()
{
     // stepper.runToNewPosition(positionA);
     // statesA_Sol();
     // statesB_Sol();

     nh.spinOnce();
     delay(1);
}
